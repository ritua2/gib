To compile the code, run the compile.sh file and before you do that, make sure that the compile.sh has execute permissions.
