#!/bin/bash

gcc -o hello hello_world.c

