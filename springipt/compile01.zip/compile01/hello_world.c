#include "hello_world.h"

int main(){
  printf("\nHello world!\n");
  return 0;
}
